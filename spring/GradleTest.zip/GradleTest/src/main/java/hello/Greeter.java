package main.java.hello;

/**
 * Created by Samuel on 2014/10/15.
 */
public class Greeter {
    public String sayHello() {
        return "Hello world!";
    }
}